<?php
defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Installer\InstallerAdapter;
use Joomla\Database\DatabaseInterface;

class Pkg_HealthcheckerInstallerScript
{
    public function preflight(string $type, InstallerAdapter $parent): bool
    {
        if (version_compare(JVERSION, '5.0.0', '<')) {
            Factory::getApplication()->enqueueMessage('Health Checker requires Joomla 5.0 or later.', 'error');
            return false;
        }
        if (version_compare(PHP_VERSION, '8.1.0', '<')) {
            Factory::getApplication()->enqueueMessage('Health Checker requires PHP 8.1 or later.', 'error');
            return false;
        }
        return true;
    }

    public function postflight(string $type, InstallerAdapter $parent): void
    {
        $this->removeObsoleteFiles();

        $this->enablePlugin('healthchecker', 'core');
        $this->enablePlugin('healthchecker', 'example');
        $this->enablePlugin('healthchecker', 'mysitesguru');

        if ($this->isExtensionInstalled('component', 'com_akeebabackup')) {
            $this->enablePlugin('healthchecker', 'akeebabackup');
        }
        if ($this->isExtensionInstalled('component', 'com_admintools')) {
            $this->enablePlugin('healthchecker', 'akeebaadmintools');
        }

        $this->publishModule('mod_healthchecker', 'cpanel');

        Factory::getApplication()->enqueueMessage(
            'Health Checker installed successfully! Access it from Components > Health Checker.',
            'success'
        );
    }

    private function enablePlugin(string $group, string $element): void
    {
        $db = Factory::getContainer()->get(DatabaseInterface::class);
        $query = $db->getQuery(true)
            ->update($db->quoteName('#__extensions'))
            ->set($db->quoteName('enabled') . ' = 1')
            ->where($db->quoteName('type') . ' = ' . $db->quote('plugin'))
            ->where($db->quoteName('folder') . ' = ' . $db->quote($group))
            ->where($db->quoteName('element') . ' = ' . $db->quote($element));
        $db->setQuery($query)->execute();
    }

    private function isExtensionInstalled(string $type, string $element): bool
    {
        $db = Factory::getContainer()->get(DatabaseInterface::class);
        $query = $db->getQuery(true)
            ->select('COUNT(*)')
            ->from($db->quoteName('#__extensions'))
            ->where($db->quoteName('type') . ' = ' . $db->quote($type))
            ->where($db->quoteName('element') . ' = ' . $db->quote($element))
            ->where($db->quoteName('enabled') . ' = 1');
        return (int) $db->setQuery($query)->loadResult() > 0;
    }

    private function removeObsoleteFiles(): void
    {
        $files = [
            JPATH_PLUGINS . '/healthchecker/core/src/Checks/Database/BackupAgeCheck.php',
            JPATH_PLUGINS . '/healthchecker/core/src/Checks/Security/UserActionsLogCheck.php',
            JPATH_PLUGINS . '/healthchecker/core/src/Checks/Extensions/LegacyExtensionsCheck.php',
        ];

        foreach ($files as $file) {
            if (file_exists($file)) {
                @unlink($file);
            }
        }
    }

    private function publishModule(string $module, string $position = 'cpanel'): void
    {
        $db = Factory::getContainer()->get(DatabaseInterface::class);
        $query = $db->getQuery(true)
            ->select($db->quoteName('id'))
            ->from($db->quoteName('#__modules'))
            ->where($db->quoteName('module') . ' = ' . $db->quote($module))
            ->where($db->quoteName('client_id') . ' = 1');
        $moduleId = $db->setQuery($query)->loadResult();

        if ($moduleId) {
            $query = $db->getQuery(true)
                ->update($db->quoteName('#__modules'))
                ->set($db->quoteName('published') . ' = 1')
                ->set($db->quoteName('position') . ' = ' . $db->quote($position))
                ->set($db->quoteName('showtitle') . ' = 1')
                ->set($db->quoteName('ordering') . ' = 1')
                ->where($db->quoteName('id') . ' = ' . (int) $moduleId);
            $db->setQuery($query)->execute();

            try {
                $query = $db->getQuery(true)
                    ->insert($db->quoteName('#__modules_menu'))
                    ->columns([$db->quoteName('moduleid'), $db->quoteName('menuid')])
                    ->values((int) $moduleId . ', 0');
                $db->setQuery($query)->execute();
            } catch (\Exception $e) {
                // Already assigned
            }
        }
    }
}
